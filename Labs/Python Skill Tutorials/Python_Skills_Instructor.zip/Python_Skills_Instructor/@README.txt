This is the instructor version of the python skills.
Eack skill has three files:
- Skill-##-NameOfSkill.ipynb - This is the worked out jupyter notebook.
  It is the instructor version.
- Skill-##-NameOfSkill-Student.ipynb - This is the student version. There 
  are cells with skipped code the student has to figure out.
- Skill-##-NameOfSkill-Student.pdf - This is the print version of the 
  student jupyter notebook above.

I zip together all of the Student files and distribute that to the 
students. They have to complete the Student jupyter notebook and send 
them to me for grading.
